from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

pd = Flask(__name__)


pd.secret_key = "mans_vecais_Audi"

@pd.before_request
def gatekeeper():
    # Saraksts ar ceļiem, kuriem var piekļūt bez ielogošanās
    # Jāpārbauda savi funkciju (funkciju, nevis path) nosaukumi!
    publiskie_celi = ['sakums',"login", 'registreties', 'static', 'chats']
    
    # Ja lietotājs nav sesijā un mēģina piekļūt ne-publiskam ceļam
    if 'id' not in session and request.endpoint not in publiskie_celi:
        return redirect("/pieteikties")

@pd.route("/")
def sakums():
    return render_template("index_pd.html")




@pd.route("/pieteikties_pd", methods = ["GET", "POST"])
def login():
    if request.method == 'POST':
        lietotajvards = request.form.get('lietotajvārds')
        parole = request.form.get('parole')

        conn = sqlite3.connect("dati_pd.db")
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM lietotaji WHERE lietotajvards = ?", (lietotajvards,))
        atbilde = c.fetchone()
        conn.close()

        if atbilde and check_password_hash(atbilde["parole"], parole):
            session["id"] = atbilde["id"]
            session["lietotajs"] = atbilde["lietotajvards"]
            session["vards"] = atbilde["vards"]
            session["tema"] = "light"
            return redirect("/")
        else:
            return "Nepareizi ievadīti dati!"
    return render_template("pieteikties_pd.html")

@pd.route("/registreties_pd", methods = ["GET", "POST"])
def registreties():
    
    if request.method == "POST":
      lietotajvards = request.form.get("lietotajvards")
      vards = request.form.get("vards")
      parole = request.form.get("parole")
      uzvards = request.form.get("uzvards")

      modernais_hash = generate_password_hash(parole)

      conn = sqlite3.connect("dati_pd.db")
      conn.row_factory = sqlite3.Row
      c = conn.cursor()

      sql_insert_dati = ("""
          INSERT INTO lietotaji (vards, uzvards, lietotajvards, parole, hash)
          VALUES (?, ?, ?, ?, ?)
          """)

      c.execute(sql_insert_dati, (vards, uzvards, lietotajvards, parole, modernais_hash))

      conn.commit()
      conn.close()
          


    return render_template("registreties_pd.html")

@pd.route('/atslegties_pd')
def logout():
    session.clear() # Iztīra visu sesiju
    return redirect("/")

@pd.route("/chats", methods=["GET", "POST"])
def chats():
    conn = sqlite3.connect("dati_pd.db")
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    if request.method == "POST":
        zina = request.form.get("zina")
        lietotajs = session["lietotajs"]

        c.execute(
        "INSERT INTO zinaas (lietotajs, zina) VALUES (?, ?)",
        (lietotajs, zina)
        )
        conn.commit()

        c.execute("SELECT * FROM zinaas")
        visas_zinas = c.fetchall()

    return render_template("chats.html")



if __name__ == "__main__":
    pd.run(debug = True)